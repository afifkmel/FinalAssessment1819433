<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
        <div style="text-align: center">
            <a href="staff" class="btn btn-success">Staff</a>
            <a href="smartphone" class="btn btn-success">Smartphones</a>
            <a href="case" class="btn btn-success">Smartphone Cases</a>
            <a href="powerbank" class="btn btn-success">Powerbanks</a>
            <a href="accessories" class="btn btn-success">Accessories</a>
        </div>
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Afeh Akmal\Desktop\gadgetStore-enhanced\resources\views/home.blade.php ENDPATH**/ ?>