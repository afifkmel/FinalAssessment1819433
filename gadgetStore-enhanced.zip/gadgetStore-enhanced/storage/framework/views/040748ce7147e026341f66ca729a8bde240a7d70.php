<?php $__env->startSection('content'); ?>

<?php if(auth()->check()): ?>

<h1 class='text-center'>Add Data to Database</h1>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(\Session::has('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e(\Session::get('success')); ?></p>
    </div>
<?php endif; ?>

<div class="form-inline justify-content-center">
<form method="POST" action="<?php echo e(action('App\Http\Controllers\SmartphoneController@store')); ?>" style="border:1px solid black; padding: 25px">
    <?php echo csrf_field(); ?>
        <h3>SMARTPHONE</h3>
        <div class="form-group">
            <input type="text" name="smartphone_name" class="form-control" placeholder="SMARTPHONE Name">
        </div>
        <div class="form-group">
            <input type="text" name="smartphone_brand" class="form-control" placeholder="Brand">
        </div>
        <div class="form-group">
            <input type="text" name="smartphone_inv_level" class="form-control" placeholder="Inventory Level">
        </div>
        <div class="form-group">
            <input type="textarea" name="smartphone_remarks" class="form-control" placeholder="Remarks">
        </div>
        <div class="form-group">
            <input type="number" name="smartphone_price" class="form-control" placeholder="Price" step="any">
        </div>
        <div class="form-group">
            <input type="number" name="staff_id" class="form-control" placeholder="Staff ID">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary text-center">Submit</button>
        </div>
</form>
</div>


<?php else: ?>


<script>window.location = "/home";</script>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Afeh Akmal\Desktop\gadgetStore-enhanced\resources\views/smartphone/create.blade.php ENDPATH**/ ?>