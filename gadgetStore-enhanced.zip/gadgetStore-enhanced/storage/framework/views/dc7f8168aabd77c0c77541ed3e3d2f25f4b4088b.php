<?php $__env->startSection('content'); ?>

<?php if(auth()->check()): ?>

<div class="row">
    <div class="col-md-12">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <div style="text-align: left">
            <a href="staff" class="btn btn-success">Staff</a>
            <a href="smartphone" class="btn btn-success">Smartphones</a>
            <a href="case" class="btn btn-success">Smartphone Cases</a>
            <a href="accessories" class="btn btn-success">Accessories</a>
            <a href="powerbank/create" class="btn btn-primary">Add Data</a>
        </div> 
        <br>
        <h3 style="text-align: center">Powerbank Table</h3>
        <br>
        <table class="table table-bordered">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Brand</th>
                <th>Inventory Level</th>
                <th>Remarks</th>
                <th>Price</th>
                <th>Staff ID</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
            <?php $__currentLoopData = $powerbank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row['id']); ?></td>
                <td><?php echo e($row['powerbank_name']); ?></td>
                <td><?php echo e($row['powerbank_brand']); ?></td>
                <td><?php echo e($row['powerbank_mah_level']); ?></td>
                <td><?php echo e($row['powerbank_remarks']); ?></td>
                <td><?php echo e($row['powerbank_price']); ?></td>
                <td><?php echo e($row['staff_id']); ?></td>
                <td><a href="<?php echo e(action('App\Http\Controllers\PowerbankController@edit', $row['id'])); ?>">Edit</a></td>
                <td>
                    <form method="POST" class="delete_form" action="<?php echo e(action('App\Http\Controllers\PowerbankController@destroy', $row['id'])); ?>">
                        <?php echo csrf_field(); ?> 

                        <input type="hidden" name="_method" value="DELETE">
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>

<?php else: ?>


<script>window.location = "/home";</script>

<?php endif; ?>

<script>
        $(document).ready(function(){
            $('.delete_form').on('submit', function(){
                if(confirm("Are you sure you want to delete?"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Afeh Akmal\Desktop\gadgetStore-enhanced\resources\views/powerbank/index.blade.php ENDPATH**/ ?>