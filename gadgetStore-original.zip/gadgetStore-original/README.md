# Group Members <br>
1- MUHAMMAD 'AFIF AKMAL BIN ADNAN 1819433 
<br>
2- TENGKU NUR IZZAH ATIRAH BT TENGKU MAHAMUD 1822438
<br>
3- HAMZA ABDULGHANI OBAIDULLAH MOHAMMAD 1824321
<br>
4- AHMAD HAZMI BIN JOHARI 1824823
<br>
<hr>

# Introduction 
Inventory management systems are essential to how businesses monitor and regulate inventories. Having the ability to calculate inventory in a timely and reliable manner is crucial for having uninterrupted business operations because inventory is also one of the main current assets on a company’s balance sheet. After a detailed discussion, we decided to create an inventory management system for a gadget store. This gadget store is well known for selling a variety of electrical products and devices such as mobile phones which consist of different popular brands. Some of the brands include Samsung, Vivo, Oppo, Huawei and many more. Other than that, this store also sells phone cables, charging bricks, power banks as well as other electrical necessities. Current staff who work at this gadget store can edit, update and delete any of the devices or products within the system. Edit button is important in reducing the amount of available products after the customer completes the purchase. Next, an update button is used in stating and notifying any update for the new stock of products at the store. Besides that, the delete button is vital in excluding the out-of-stock products within the inventory system. Hence, the importance of this inventory system is to update the availability of the stocks of any products at the store.
<br>
<hr>

# Objective <br>
The objective of the Inventory management systems is to monitor and regulate inventories. Our objective are as follows: <br>
<ul>
<li>Provide the consumers with an online platform to keep track of the stock available in the store.</li>
<li>Creating a platform which enables the users to update, delete and edit.</li>
<li>Making sure there are no flaws or mistakes in the system to enable a swift process and a flawless system.</li>
<li>Helping new businesses in creating a system that can store all necessary information for their inventories.</li>
</ul>
<hr>

# FEATURES AND FUNCTIONALITIES OF THE WEB APPLICATION
<img width="536" alt="1" src="https://user-images.githubusercontent.com/61685490/121810614-29983880-cc94-11eb-8c96-d97c775b97a9.png">

# SPECIFIC USER REQUIREMENT 
i) User Interface<br>
● This user interface must be easy to use, user friendly and convenient to learn especially for the new employees.<br> ● All of the buttons or menu including available items for sale and edit button must be functioning well and practical to use.<br> 
ii) Operational Characteristics<br> 
● This system must be updated from time to time as the staffs must update and edit the available and unavailable product once a purchase is done or after a restock<br>
<br>
<hr>

# ABOUT THE SYSTEM / THE FlOW 
First and foremost, the employee needs to enter their username and password at the login page. All of the employees’ information including their email, password and name are already filled into the coding which is vital for their log in process to the system. If the individual incorrectly enters the wrong username or password, they cannot have access to our advanced system. Afterwards, the system will redirect to a page which specifically displays the available items on this store. By this means, the employees can check and update the number of available items after the customer completed a purchase or after a restock was done. On this system, there are a variety of products which includes different brands of smartphones, phone cables, charging bricks, power banks, phone cases and other accessories as stated in the store inventory.
<br>
<hr>

# CONTENTS IN THE CODING
![IMG_20210613_222943](https://user-images.githubusercontent.com/61685490/121812370-26a04680-cc9a-11eb-9533-4767a24f996f.jpg)
<br>
<hr>

# CONCLUSION 
Conclusively, for the purpose of developing a system, all important folders including controller, model database, view and routes must be prepared thoroughly. As a team, we cooperatively brainstormed, discussed and decided to link all of the files together in order to establish a functional system. We have to admit that these tasks were difficult especially ODL, however, we have the spirit and passion for this project with the intention of making this system a success. This system is vital for a successful business in the interest of avoiding any loss of items or products without anyone knowing. Other than this, this system is also beneficial for the employees to update the number of available items in the store for everyone to see.
<br>
<hr>
